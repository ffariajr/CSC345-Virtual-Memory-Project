#ifndef IMPORTS_H
#define IMPORTS_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

//verbose execution
extern int v;

//output process information
extern int proutput;

//output memory usage information
extern int memoutput;

//output in tablular form (delimeted by \t)
extern int tabular;

//output end of program system summary info
extern int sysoutput;

#endif
