#ifndef RRSCHED_H
#define RRSCHED_H

#include "imports.h"
#include "pcbl.h"

void rrsched(pcbl**, pcbl**);

#endif
