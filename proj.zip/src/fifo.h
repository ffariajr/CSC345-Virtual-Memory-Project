#ifndef FIFO_H
#define FIFO_H

#include "imports.h"
#include "frame.h"

void fifoRepl(frame**);

#endif
