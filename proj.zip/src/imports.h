#ifndef IMPORTS_H
#define IMPORTS_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

extern int v;
extern int proutput;
extern int memoutput;
extern int tabular;
extern int sysoutput;

#endif
